const grammar = [
  [
    {
      "ar": "أقسام الكلام",
      "en": "Parts of speech"
    },
    {
      "ar": "الكلمة اسم أو فعل أو حرف. الاسم يدل على معنى غير مرتبط بزمن، والفعل يدل على حدث مرتبط بزمن، والحرف يظهر معناه مع غيره.",
      "en": "A word is a noun, verb or particle. A noun expresses a meaning independent of time; a verb expresses an event associated with time; a particle conveys its meaning with other words."
    },
    {
      "ar": "قرأَ عليٌّ في المكتبةِ.",
      "en": "Ali read in the library."
    },
    [
      [
        {
          "ar": "ما نوع كلمة قرأ؟",
          "en": "What part of speech is qara’a (read)?"
        },
        {
          "ar": "فعل",
          "en": "Verb"
        },
        {
          "ar": "اسم",
          "en": "Noun"
        },
        {
          "ar": "حرف",
          "en": "Particle"
        },
        {
          "ar": "تدل على حدث في الماضي.",
          "en": "It expresses a past event."
        }
      ],
      [
        {
          "ar": "ما نوع في؟",
          "en": "What is fi (in)?"
        },
        {
          "ar": "حرف",
          "en": "Particle"
        },
        {
          "ar": "فعل",
          "en": "Verb"
        },
        {
          "ar": "اسم",
          "en": "Noun"
        },
        {
          "ar": "في حرف جر.",
          "en": "Fi is a preposition."
        }
      ]
    ]
  ],
  [
    {
      "ar": "المعرب والمبني",
      "en": "Inflected and fixed-ending words"
    },
    {
      "ar": "المعرب يتغير آخره بحسب موقعه، والمبني يلزم آخره حالة واحدة.",
      "en": "An inflected word changes its ending according to its grammatical role; a fixed-ending word retains the same ending."
    },
    {
      "ar": "جاء الطالبُ، رأيت الطالبَ، مررت بالطالبِ.",
      "en": "The student came; I saw the student; I passed by the student."
    },
    [
      [
        {
          "ar": "أي الكلمات مبنية؟",
          "en": "Which word has a fixed ending?"
        },
        {
          "ar": "هذا",
          "en": "This (hadha)"
        },
        {
          "ar": "طالب",
          "en": "Student"
        },
        {
          "ar": "كتاب",
          "en": "Book"
        },
        {
          "ar": "اسم الإشارة هذا مبني.",
          "en": "Hadha is a fixed-ending demonstrative."
        }
      ],
      [
        {
          "ar": "ما حركة الطالب في رأيت الطالب؟",
          "en": "What is the ending of al-talib in “I saw the student”?"
        },
        {
          "ar": "الفتحة",
          "en": "Fatha (a)"
        },
        {
          "ar": "الضمة",
          "en": "Damma (u)"
        },
        {
          "ar": "الكسرة",
          "en": "Kasra (i)"
        },
        {
          "ar": "مفعول به منصوب.",
          "en": "It is an accusative direct object."
        }
      ]
    ]
  ],
  [
    {
      "ar": "العلم",
      "en": "Proper nouns"
    },
    {
      "ar": "العلم اسم معرفة يدل على معين بذاته، مثل أسماء الأشخاص والبلدان.",
      "en": "A proper noun is a definite noun identifying a specific person or place, such as personal and country names."
    },
    {
      "ar": "سافرت مريم إلى البصرة.",
      "en": "Maryam travelled to Basra."
    },
    [
      [
        {
          "ar": "أيها علم؟",
          "en": "Which is a proper noun?"
        },
        {
          "ar": "البصرة",
          "en": "Basra"
        },
        {
          "ar": "مدينة",
          "en": "City"
        },
        {
          "ar": "قلم",
          "en": "Pen"
        },
        {
          "ar": "اسم مدينة محددة.",
          "en": "It names a specific city."
        }
      ],
      [
        {
          "ar": "أيها اسم شخص؟",
          "en": "Which is a personal name?"
        },
        {
          "ar": "مريم",
          "en": "Maryam"
        },
        {
          "ar": "طالبة",
          "en": "Female student"
        },
        {
          "ar": "مدرسة",
          "en": "School"
        },
        {
          "ar": "مريم علم.",
          "en": "Maryam is a proper noun."
        }
      ]
    ]
  ],
  [
    {
      "ar": "المعرف بأل",
      "en": "Definiteness with al-"
    },
    {
      "ar": "تدخل أل على الاسم النكرة فتجعله معرفة في الاستعمال المعتاد.",
      "en": "The definite article al- normally makes an indefinite noun definite."
    },
    {
      "ar": "كتابٌ — الكتابُ.",
      "en": "A book — the book."
    },
    [
      [
        {
          "ar": "أيها معرفة بأل؟",
          "en": "Which noun is definite through al-?"
        },
        {
          "ar": "الحديقة",
          "en": "The garden"
        },
        {
          "ar": "حديقة",
          "en": "A garden"
        },
        {
          "ar": "حدائق",
          "en": "Gardens"
        },
        {
          "ar": "دخلت أل على الاسم.",
          "en": "Al- has been added to the noun."
        }
      ],
      [
        {
          "ar": "عرّف كلمة قلم بأل.",
          "en": "Make qalam (pen) definite using al-."
        },
        {
          "ar": "القلم",
          "en": "The pen (al-qalam)"
        },
        {
          "ar": "قلمي",
          "en": "My pen"
        },
        {
          "ar": "أقلام",
          "en": "Pens"
        },
        {
          "ar": "نضيف أل.",
          "en": "We add al-."
        }
      ]
    ]
  ],
  [
    {
      "ar": "الضمائر",
      "en": "Pronouns"
    },
    {
      "ar": "الضمير اسم معرفة يدل على متكلم أو مخاطب أو غائب، وقد يكون متصلا أو منفصلا.",
      "en": "A pronoun is a definite noun referring to the speaker, addressee or third person. It may be attached or independent."
    },
    {
      "ar": "أنا أقرأ، أنتِ تكتبين، هو يرسم.",
      "en": "I read, you (feminine) write, he draws."
    },
    [
      [
        {
          "ar": "ضمير المخاطبة للمفرد المؤنث؟",
          "en": "Which pronoun addresses one female?"
        },
        {
          "ar": "أنتِ",
          "en": "You (anti)"
        },
        {
          "ar": "أنا",
          "en": "I"
        },
        {
          "ar": "هي",
          "en": "She"
        },
        {
          "ar": "يدل على من نخاطبها.",
          "en": "It refers to the female addressee."
        }
      ],
      [
        {
          "ar": "أيها ضمير متصل في كتابي؟",
          "en": "Which is the attached pronoun in kitabi (my book)?"
        },
        {
          "ar": "الياء",
          "en": "Ya (y)"
        },
        {
          "ar": "الكاف",
          "en": "Kaf (k)"
        },
        {
          "ar": "الباء",
          "en": "Ba (b)"
        },
        {
          "ar": "ياء المتكلم مضافة إلى الاسم.",
          "en": "The first-person ya is attached to the noun."
        }
      ]
    ]
  ],
  [
    {
      "ar": "أسماء الإشارة",
      "en": "Demonstratives"
    },
    {
      "ar": "تدل على معين بالإشارة إليه، مثل هذا وهذه وهذان وهاتان وهؤلاء.",
      "en": "These identify something by pointing to it, such as this (masculine or feminine), these two (masculine or feminine), and these."
    },
    {
      "ar": "هذه شجرةٌ، وهؤلاء تلاميذ.",
      "en": "This is a tree; these are pupils."
    },
    [
      [
        {
          "ar": "أشر إلى مفرد مؤنث.",
          "en": "Point to one feminine noun."
        },
        {
          "ar": "هذه",
          "en": "This (hadhihi)"
        },
        {
          "ar": "هذا",
          "en": "This (hadha)"
        },
        {
          "ar": "هؤلاء",
          "en": "These"
        },
        {
          "ar": "هذه للمفرد المؤنث.",
          "en": "Hadhihi is feminine singular."
        }
      ],
      [
        {
          "ar": "أشر إلى جمع العقلاء.",
          "en": "Point to a group of people."
        },
        {
          "ar": "هؤلاء",
          "en": "These (ha’ula’i)"
        },
        {
          "ar": "هذا",
          "en": "This"
        },
        {
          "ar": "هاتان",
          "en": "These two (feminine)"
        },
        {
          "ar": "هؤلاء للجمع.",
          "en": "Ha’ula’i is plural."
        }
      ]
    ]
  ],
  [
    {
      "ar": "الأسماء الموصولة",
      "en": "Relative pronouns"
    },
    {
      "ar": "اسم معرفة يحتاج إلى صلة توضّح معناه، مثل الذي والتي والذين.",
      "en": "A definite noun that requires a relative clause to clarify its meaning, such as alladhi, allati and alladhina."
    },
    {
      "ar": "أحب الطالبة التي تجتهد في دروسها.",
      "en": "I like the female student who works hard in her studies."
    },
    [
      [
        {
          "ar": "ما الاسم الموصول؟",
          "en": "What is the relative pronoun?"
        },
        {
          "ar": "التي",
          "en": "Who (allati)"
        },
        {
          "ar": "هذه",
          "en": "This (feminine)"
        },
        {
          "ar": "هي",
          "en": "She"
        },
        {
          "ar": "التي للمفرد المؤنث.",
          "en": "Allati is feminine singular."
        }
      ],
      [
        {
          "ar": "ما الصلة في جاء الذي نجح؟",
          "en": "What is the relative clause in “The one who succeeded came”?"
        },
        {
          "ar": "نجح",
          "en": "Succeeded"
        },
        {
          "ar": "الذي",
          "en": "Who (alladhi)"
        },
        {
          "ar": "جاء",
          "en": "Came"
        },
        {
          "ar": "جملة الصلة توضح المقصود.",
          "en": "The relative clause clarifies the intended person."
        }
      ]
    ]
  ],
  [
    {
      "ar": "المعرف بالإضافة",
      "en": "Definiteness through the possessive construction"
    },
    {
      "ar": "إذا أضيف اسم نكرة إلى معرفة اكتسب التعريف، والمضاف إليه مجرور.",
      "en": "When an indefinite noun is linked to a definite noun in an idafa construction, it becomes definite. The second noun is genitive."
    },
    {
      "ar": "كتابُ الطالبِ جديدٌ.",
      "en": "The student’s book is new."
    },
    [
      [
        {
          "ar": "ما المضاف إليه؟",
          "en": "Which is the second noun of the idafa?"
        },
        {
          "ar": "الطالب",
          "en": "The student"
        },
        {
          "ar": "كتاب",
          "en": "Book"
        },
        {
          "ar": "جديد",
          "en": "New"
        },
        {
          "ar": "الطالب مضاف إليه.",
          "en": "The student is the genitive complement."
        }
      ],
      [
        {
          "ar": "حركة المضاف إليه المفرد؟",
          "en": "What is the ending of a singular genitive complement?"
        },
        {
          "ar": "الكسرة",
          "en": "Kasra (i)"
        },
        {
          "ar": "الضمة",
          "en": "Damma (u)"
        },
        {
          "ar": "الفتحة",
          "en": "Fatha (a)"
        },
        {
          "ar": "علامة جره الأصلية الكسرة.",
          "en": "Its basic genitive marker is kasra."
        }
      ]
    ]
  ],
  [
    {
      "ar": "الفعل الماضي",
      "en": "Past tense"
    },
    {
      "ar": "يدل على حدث وقع قبل زمن التكلم وهو مبني.",
      "en": "It expresses an event before the time of speaking and has a fixed ending."
    },
    {
      "ar": "كتبَ الطالبُ واجبَه.",
      "en": "The student wrote his homework."
    },
    [
      [
        {
          "ar": "أيها ماض؟",
          "en": "Which is past tense?"
        },
        {
          "ar": "كتبَ",
          "en": "Wrote"
        },
        {
          "ar": "يكتبُ",
          "en": "Writes"
        },
        {
          "ar": "اكتبْ",
          "en": "Write!"
        },
        {
          "ar": "وقع الحدث في الماضي.",
          "en": "The event occurred in the past."
        }
      ],
      [
        {
          "ar": "كتبوا: علامة البناء؟",
          "en": "What is the fixed ending of katabu (they wrote)?"
        },
        {
          "ar": "الضم",
          "en": "Damma"
        },
        {
          "ar": "الفتح",
          "en": "Fatha"
        },
        {
          "ar": "السكون",
          "en": "Sukun"
        },
        {
          "ar": "لاتصاله بواو الجماعة.",
          "en": "Because the plural waw is attached."
        }
      ]
    ]
  ],
  [
    {
      "ar": "رفع المضارع",
      "en": "Indicative present tense"
    },
    {
      "ar": "يرفع المضارع إذا لم يسبقه ناصب أو جازم، وعلامته الأصلية الضمة.",
      "en": "The present verb is indicative unless preceded by a subjunctive or jussive particle. Its basic marker is damma."
    },
    {
      "ar": "يقرأُ الطفلُ قصةً.",
      "en": "The child reads a story."
    },
    [
      [
        {
          "ar": "ما حركة يقرأُ؟",
          "en": "What is the ending of yaqra’u?"
        },
        {
          "ar": "الضمة",
          "en": "Damma"
        },
        {
          "ar": "الفتحة",
          "en": "Fatha"
        },
        {
          "ar": "السكون",
          "en": "Sukun"
        },
        {
          "ar": "مضارع مرفوع.",
          "en": "The present verb is indicative."
        }
      ]
    ]
  ],
  [
    {
      "ar": "نصب المضارع",
      "en": "Subjunctive present tense"
    },
    {
      "ar": "ينصب المضارع بعد أدوات مثل أن ولن وكي، وعلامته الأصلية الفتحة.",
      "en": "The present verb becomes subjunctive after particles such as an, lan and kay. Its basic marker is fatha."
    },
    {
      "ar": "لن أهملَ واجبي.",
      "en": "I will not neglect my homework."
    },
    [
      [
        {
          "ar": "ما الأداة الناصبة؟",
          "en": "Which is the subjunctive particle?"
        },
        {
          "ar": "لن",
          "en": "Lan (will not)"
        },
        {
          "ar": "لم",
          "en": "Lam (did not)"
        },
        {
          "ar": "هل",
          "en": "Hal (question particle)"
        },
        {
          "ar": "لن تنصب المضارع.",
          "en": "Lan makes the present verb subjunctive."
        }
      ]
    ]
  ],
  [
    {
      "ar": "جزم المضارع",
      "en": "Jussive present tense"
    },
    {
      "ar": "يجزم المضارع بعد لم ولا الناهية ولام الأمر، وعلامته الأصلية السكون.",
      "en": "The present verb becomes jussive after lam, prohibitive la and imperative lam. Its basic marker is sukun."
    },
    {
      "ar": "لم يذهبْ عليٌّ.",
      "en": "Ali did not go."
    },
    [
      [
        {
          "ar": "ما علامة جزم يذهب؟",
          "en": "What is the jussive marker of yadhhab?"
        },
        {
          "ar": "السكون",
          "en": "Sukun"
        },
        {
          "ar": "الضمة",
          "en": "Damma"
        },
        {
          "ar": "الفتحة",
          "en": "Fatha"
        },
        {
          "ar": "صحيح الآخر مجزوم بالسكون.",
          "en": "A regular-ending verb takes sukun in the jussive."
        }
      ]
    ]
  ],
  [
    {
      "ar": "الأفعال الخمسة",
      "en": "The five verb forms"
    },
    {
      "ar": "كل مضارع اتصل بألف الاثنين أو واو الجماعة أو ياء المخاطبة. ترفع بثبوت النون وتنصب وتجزم بحذفها.",
      "en": "Present verbs attached to dual alif, plural waw or feminine-address ya retain nun in the indicative and lose it in the subjunctive and jussive."
    },
    {
      "ar": "الطالبان يكتبان، لن يكتبا.",
      "en": "The two students write; they two will not write."
    },
    [
      [
        {
          "ar": "علامة رفع يكتبان؟",
          "en": "What marks yaktuban as indicative?"
        },
        {
          "ar": "ثبوت النون",
          "en": "Retention of nun"
        },
        {
          "ar": "الضمة",
          "en": "Damma"
        },
        {
          "ar": "حذف النون",
          "en": "Deletion of nun"
        },
        {
          "ar": "من الأفعال الخمسة.",
          "en": "It belongs to the five verb forms."
        }
      ]
    ]
  ],
  [
    {
      "ar": "فعل الأمر",
      "en": "Imperative verb"
    },
    {
      "ar": "يدل على طلب حصول الفعل، ويبنى على ما يجزم به مضارعه.",
      "en": "It requests an action and is built on the ending used for the jussive form of its present verb."
    },
    {
      "ar": "اكتبْ واجبك.",
      "en": "Write your homework."
    },
    [
      [
        {
          "ar": "أيها أمر؟",
          "en": "Which is an imperative?"
        },
        {
          "ar": "اكتبْ",
          "en": "Write!"
        },
        {
          "ar": "كتبَ",
          "en": "Wrote"
        },
        {
          "ar": "يكتبُ",
          "en": "Writes"
        },
        {
          "ar": "يدل على الطلب.",
          "en": "It expresses a request."
        }
      ]
    ]
  ],
  [
    {
      "ar": "الفاعل",
      "en": "Subject of a verb"
    },
    {
      "ar": "اسم مرفوع يدل على من قام بالفعل أو اتصف به.",
      "en": "A nominative noun identifying who performs an action or is described by it."
    },
    {
      "ar": "رسمتْ سارةُ لوحةً.",
      "en": "Sarah drew a picture."
    },
    [
      [
        {
          "ar": "ما الفاعل؟",
          "en": "What is the subject?"
        },
        {
          "ar": "سارة",
          "en": "Sarah"
        },
        {
          "ar": "لوحة",
          "en": "Picture"
        },
        {
          "ar": "رسمت",
          "en": "Drew"
        },
        {
          "ar": "سارة قامت بالفعل.",
          "en": "Sarah performed the action."
        }
      ]
    ]
  ],
  [
    {
      "ar": "صور الفاعل",
      "en": "Forms of the verbal subject"
    },
    {
      "ar": "قد يكون الفاعل اسما ظاهرا أو ضميرا متصلا أو مستترا.",
      "en": "The subject can be an explicit noun, an attached pronoun or an implicit pronoun."
    },
    {
      "ar": "كتبتُ الدرسَ.",
      "en": "I wrote the lesson."
    },
    [
      [
        {
          "ar": "ما الفاعل في كتبتُ؟",
          "en": "What is the subject in katabtu?"
        },
        {
          "ar": "تاء المتكلم",
          "en": "First-person ta"
        },
        {
          "ar": "الدرس",
          "en": "The lesson"
        },
        {
          "ar": "الكاف",
          "en": "Kaf"
        },
        {
          "ar": "التاء ضمير في محل رفع فاعل.",
          "en": "Ta is a pronoun in the nominative subject position."
        }
      ]
    ]
  ],
  [
    {
      "ar": "المفعول به",
      "en": "Direct object"
    },
    {
      "ar": "اسم منصوب يدل على من وقع عليه الفعل.",
      "en": "An accusative noun identifying what receives the action."
    },
    {
      "ar": "قرأ عليٌّ الكتابَ.",
      "en": "Ali read the book."
    },
    [
      [
        {
          "ar": "ما المفعول به؟",
          "en": "What is the direct object?"
        },
        {
          "ar": "الكتاب",
          "en": "The book"
        },
        {
          "ar": "علي",
          "en": "Ali"
        },
        {
          "ar": "قرأ",
          "en": "Read"
        },
        {
          "ar": "وقع عليه فعل القراءة.",
          "en": "It receives the action of reading."
        }
      ]
    ]
  ],
  [
    {
      "ar": "المبتدأ والخبر",
      "en": "Nominal subject and predicate"
    },
    {
      "ar": "ركنا الجملة الاسمية، وهما مرفوعان في الأصل.",
      "en": "The two main parts of a nominal sentence are normally nominative."
    },
    {
      "ar": "السماءُ صافيةٌ.",
      "en": "The sky is clear."
    },
    [
      [
        {
          "ar": "ما الخبر؟",
          "en": "What is the predicate?"
        },
        {
          "ar": "صافية",
          "en": "Clear"
        },
        {
          "ar": "السماء",
          "en": "The sky"
        },
        {
          "ar": "الجملة",
          "en": "The sentence"
        },
        {
          "ar": "يتمم معنى المبتدأ.",
          "en": "It completes the meaning of the subject."
        }
      ]
    ]
  ],
  [
    {
      "ar": "كان وأخواتها",
      "en": "Kana and its sisters"
    },
    {
      "ar": "تدخل على الجملة الاسمية فترفع المبتدأ اسما لها وتنصب الخبر.",
      "en": "They enter a nominal sentence, keeping the subject nominative as their noun and making the predicate accusative."
    },
    {
      "ar": "كان الجوُّ معتدلاً.",
      "en": "The weather was mild."
    },
    [
      [
        {
          "ar": "ما خبر كان؟",
          "en": "What is the predicate of kana?"
        },
        {
          "ar": "معتدلاً",
          "en": "Mild"
        },
        {
          "ar": "الجو",
          "en": "The weather"
        },
        {
          "ar": "كان",
          "en": "Was"
        },
        {
          "ar": "خبر كان منصوب.",
          "en": "The predicate of kana is accusative."
        }
      ]
    ]
  ],
  [
    {
      "ar": "إن وأخواتها",
      "en": "Inna and its sisters"
    },
    {
      "ar": "تدخل على الجملة الاسمية فتنصب المبتدأ اسما لها وترفع الخبر.",
      "en": "They enter a nominal sentence, making the subject accusative as their noun and keeping the predicate nominative."
    },
    {
      "ar": "إن العلمَ نورٌ.",
      "en": "Indeed, knowledge is light."
    },
    [
      [
        {
          "ar": "ما اسم إن؟",
          "en": "What is the noun of inna?"
        },
        {
          "ar": "العلم",
          "en": "Knowledge"
        },
        {
          "ar": "نور",
          "en": "Light"
        },
        {
          "ar": "إن",
          "en": "Indeed"
        },
        {
          "ar": "اسم إن منصوب.",
          "en": "The noun of inna is accusative."
        }
      ]
    ]
  ],
  [
    {
      "ar": "مراجعة النواسخ",
      "en": "Review of governing particles and verbs"
    },
    {
      "ar": "كان ترفع الاسم وتنصب الخبر، وإن تنصب الاسم وترفع الخبر.",
      "en": "Kana keeps its noun nominative and makes its predicate accusative; inna makes its noun accusative and keeps its predicate nominative."
    },
    {
      "ar": "كان الطالبُ نشيطاً. إن الطالبَ نشيطٌ.",
      "en": "The student was active. Indeed, the student is active."
    },
    [
      [
        {
          "ar": "أي جملة صحيحة؟",
          "en": "Which sentence has the correct Arabic endings?"
        },
        {
          "ar": "إن الطالبَ نشيطٌ",
          "en": "Inna al-taliba nashitun"
        },
        {
          "ar": "إن الطالبُ نشيطاً",
          "en": "Inna al-talibu nashitan"
        },
        {
          "ar": "إن الطالبُ نشيطٌ",
          "en": "Inna al-talibu nashitun"
        },
        {
          "ar": "اسم إن منصوب وخبرها مرفوع.",
          "en": "The noun of inna is accusative and its predicate nominative."
        }
      ]
    ]
  ]
];
const reading = [
  [
    {
      "ar": "من نعم الله",
      "en": "God’s blessings"
    },
    {
      "ar": "الماء نعمة عظيمة. تسقي الأمطار الأرض فتنبت النباتات، ويشرب الإنسان والحيوان. لذلك نحافظ على الماء ولا نسرف في استعماله.",
      "en": "Water is a great blessing. Rain waters the earth so plants grow, and people and animals drink. We therefore conserve water and avoid wasting it."
    },
    [
      {
        "ar": "كيف نحافظ على الماء؟",
        "en": "How do we conserve water?"
      },
      {
        "ar": "بعدم الإسراف",
        "en": "By avoiding waste"
      },
      {
        "ar": "بترك الصنبور مفتوحا",
        "en": "By leaving the tap open"
      },
      {
        "ar": "بتلويث النهر",
        "en": "By polluting the river"
      },
      {
        "ar": "المحافظة على النعمة مسؤولية.",
        "en": "Protecting this blessing is a responsibility."
      }
    ]
  ],
  [
    {
      "ar": "طلب العلم",
      "en": "Seeking knowledge"
    },
    {
      "ar": "تذهب زهراء إلى المكتبة كل أسبوع. تختار كتابا جديدا وتسجل ما تعلمته في دفتر صغير. وحين يصعب عليها موضوع تسأل معلمتها.",
      "en": "Zahra visits the library every week. She chooses a new book and records what she learns in a small notebook. When a topic is difficult, she asks her teacher."
    },
    [
      {
        "ar": "ماذا تفعل حين يصعب الموضوع؟",
        "en": "What does she do when a topic is difficult?"
      },
      {
        "ar": "تسأل معلمتها",
        "en": "Asks her teacher"
      },
      {
        "ar": "تترك الدراسة",
        "en": "Stops studying"
      },
      {
        "ar": "تمزق الكتاب",
        "en": "Tears the book"
      },
      {
        "ar": "السؤال يساعد على التعلم.",
        "en": "Asking questions helps learning."
      }
    ]
  ],
  [
    {
      "ar": "من عظمائنا",
      "en": "Our great figures"
    },
    {
      "ar": "اهتم الرحالة العرب بوصف البلدان التي زاروها. سجلوا عادات الناس وطرق عيشهم، فبقيت كتبهم مصدرا لمعرفة الماضي.",
      "en": "Arab travellers took care to describe the countries they visited. They recorded people’s customs and ways of life, so their books remain a source of knowledge about the past."
    },
    [
      {
        "ar": "لماذا تفيد كتب الرحالة؟",
        "en": "Why are travellers’ books useful?"
      },
      {
        "ar": "لمعرفة الماضي",
        "en": "To learn about the past"
      },
      {
        "ar": "لإضاعة الوقت",
        "en": "To waste time"
      },
      {
        "ar": "لتعلم السباحة",
        "en": "To learn swimming"
      },
      {
        "ar": "تصف حياة الناس قديما.",
        "en": "They describe people’s lives in the past."
      }
    ]
  ],
  [
    {
      "ar": "نعم للقراءة",
      "en": "Yes to reading"
    },
    {
      "ar": "الكتاب صديق يمنحنا المعرفة. يستطيع القارئ أن يتعرف على أماكن بعيدة دون أن يغادر غرفته، وأن يكتسب أفكارا جديدة كل يوم.",
      "en": "A book is a friend that gives us knowledge. Readers can discover distant places without leaving their rooms and gain new ideas every day."
    },
    [
      {
        "ar": "ماذا تمنحنا القراءة؟",
        "en": "What does reading give us?"
      },
      {
        "ar": "المعرفة",
        "en": "Knowledge"
      },
      {
        "ar": "الكسل",
        "en": "Laziness"
      },
      {
        "ar": "الضوضاء",
        "en": "Noise"
      },
      {
        "ar": "القراءة توسع المعرفة.",
        "en": "Reading broadens knowledge."
      }
    ]
  ],
  [
    {
      "ar": "حسن الخلق",
      "en": "Good character"
    },
    {
      "ar": "وجدت مريم محفظة في ساحة المدرسة، فأعطتها للمعلمة لتعيدها إلى صاحبتها. شكر الجميع مريم على أمانتها.",
      "en": "Maryam found a wallet in the schoolyard and gave it to the teacher to return to its owner. Everyone thanked Maryam for her honesty."
    },
    [
      {
        "ar": "ما الصفة التي أظهرتها مريم؟",
        "en": "What quality did Maryam show?"
      },
      {
        "ar": "الأمانة",
        "en": "Honesty"
      },
      {
        "ar": "الغرور",
        "en": "Arrogance"
      },
      {
        "ar": "الإهمال",
        "en": "Neglect"
      },
      {
        "ar": "أعادت ما ليس لها.",
        "en": "She returned what did not belong to her."
      }
    ]
  ],
  [
    {
      "ar": "المظاهر الخادعة",
      "en": "Deceptive appearances"
    },
    {
      "ar": "ظن سامر أن هدية صديقه البسيطة لا قيمة لها. لكنه اكتشف أنها صنعت بيديه خلال أيام. أدرك أن المحبة أهم من ثمن الهدية.",
      "en": "Samer thought his friend’s simple gift was worthless. But he discovered that his friend had made it by hand over several days. He realised that affection matters more than the price of a gift."
    },
    [
      {
        "ar": "ما الفكرة الرئيسة؟",
        "en": "What is the main idea?"
      },
      {
        "ar": "قيمة المحبة",
        "en": "The value of affection"
      },
      {
        "ar": "ارتفاع الأسعار",
        "en": "Rising prices"
      },
      {
        "ar": "شراء الهدايا الغالية",
        "en": "Buying expensive gifts"
      },
      {
        "ar": "القيمة لا تقاس بالمظهر وحده.",
        "en": "Value is not measured by appearance alone."
      }
    ]
  ],
  [
    {
      "ar": "التسامح",
      "en": "Tolerance"
    },
    {
      "ar": "اختلف طالبان في لعبة، ثم تحدثا بهدوء واعتذر كل منهما للآخر. عادا إلى اللعب دون خصام.",
      "en": "Two students disagreed during a game, then spoke calmly and apologised to each other. They returned to playing without quarrelling."
    },
    [
      {
        "ar": "كيف حلا الخلاف؟",
        "en": "How did they resolve the disagreement?"
      },
      {
        "ar": "بالحوار والاعتذار",
        "en": "Through dialogue and apologies"
      },
      {
        "ar": "بالصراخ",
        "en": "By shouting"
      },
      {
        "ar": "بالمقاطعة",
        "en": "By refusing to speak"
      },
      {
        "ar": "الحوار يعيد المودة.",
        "en": "Dialogue restores friendship."
      }
    ]
  ],
  [
    {
      "ar": "وطننا الحبيب",
      "en": "Our beloved homeland"
    },
    {
      "ar": "يحب أبناء العراق وطنهم ويحافظون على مدنه وأنهاره. يتعاونون في تنظيف الأحياء ومساعدة الجيران.",
      "en": "The people of Iraq love their country and protect its cities and rivers. They cooperate in cleaning neighbourhoods and helping neighbours."
    },
    [
      {
        "ar": "كيف نخدم الوطن؟",
        "en": "How do we serve our country?"
      },
      {
        "ar": "بالتعاون",
        "en": "Through cooperation"
      },
      {
        "ar": "بإتلاف الممتلكات",
        "en": "By damaging property"
      },
      {
        "ar": "بإهمال الجيران",
        "en": "By neglecting neighbours"
      },
      {
        "ar": "التعاون يخدم المجتمع.",
        "en": "Cooperation serves society."
      }
    ]
  ],
  [
    {
      "ar": "منزلة المرأة",
      "en": "The status of women"
    },
    {
      "ar": "تعمل الطبيبة والمعلمة والمهندسة لخدمة المجتمع. وبالعلم والعمل تستطيع المرأة أن تحقق أحلامها وتساهم في بناء الوطن.",
      "en": "Doctors, teachers and engineers who are women work to serve society. Through knowledge and work, women can achieve their dreams and contribute to building the country."
    },
    [
      {
        "ar": "ما وسيلة تحقيق الأحلام؟",
        "en": "How can dreams be achieved?"
      },
      {
        "ar": "العلم والعمل",
        "en": "Through knowledge and work"
      },
      {
        "ar": "الكسل",
        "en": "Through laziness"
      },
      {
        "ar": "الإهمال",
        "en": "Through neglect"
      },
      {
        "ar": "الاجتهاد يحقق الأهداف.",
        "en": "Diligence helps achieve goals."
      }
    ]
  ],
  [
    {
      "ar": "لغتنا العربية",
      "en": "Our Arabic language"
    },
    {
      "ar": "تجمع اللغة العربية ملايين الناس وتفتح أبواب المعرفة والتراث. نحافظ عليها بالقراءة والكتابة السليمة.",
      "en": "Arabic connects millions of people and opens doors to knowledge and heritage. We preserve it through reading and correct writing."
    },
    [
      {
        "ar": "كيف نحافظ على اللغة؟",
        "en": "How do we preserve the language?"
      },
      {
        "ar": "بالقراءة والكتابة",
        "en": "Through reading and writing"
      },
      {
        "ar": "بهجر الكتب",
        "en": "By abandoning books"
      },
      {
        "ar": "بتجنب الحديث",
        "en": "By avoiding conversation"
      },
      {
        "ar": "الممارسة تقوي اللغة.",
        "en": "Practice strengthens language."
      }
    ]
  ],
  [
    {
      "ar": "بيئتنا",
      "en": "Our environment"
    },
    {
      "ar": "زرع التلاميذ أشجارا في المدرسة ووضعوا حاويات للنفايات. أصبحت الساحة أجمل والهواء ألطف.",
      "en": "Pupils planted trees at school and placed rubbish bins. The yard became more beautiful and the air more pleasant."
    },
    [
      {
        "ar": "ماذا زرع التلاميذ؟",
        "en": "What did the pupils plant?"
      },
      {
        "ar": "أشجارا",
        "en": "Trees"
      },
      {
        "ar": "حجارة",
        "en": "Stones"
      },
      {
        "ar": "أوراقا",
        "en": "Sheets of paper"
      },
      {
        "ar": "الأشجار تحسن البيئة.",
        "en": "Trees improve the environment."
      }
    ]
  ],
  [
    {
      "ar": "الإيثار",
      "en": "Altruism"
    },
    {
      "ar": "كان مع حسن رغيف واحد، فرأى زميلا جائعا وقاسمه طعامه. شعر بالسعادة لأنه ساعد صديقه.",
      "en": "Hasan had one loaf of bread. He saw a hungry classmate and shared his food. He felt happy because he helped his friend."
    },
    [
      {
        "ar": "ما معنى الإيثار في النص؟",
        "en": "What does altruism mean in the passage?"
      },
      {
        "ar": "مساعدة الغير ولو احتجنا",
        "en": "Helping others even when we are in need"
      },
      {
        "ar": "الأنانية",
        "en": "Selfishness"
      },
      {
        "ar": "التفاخر",
        "en": "Boasting"
      },
      {
        "ar": "شارك حسن طعامه.",
        "en": "Hasan shared his food."
      }
    ]
  ],
  [
    {
      "ar": "من تراث العرب",
      "en": "Arab heritage"
    },
    {
      "ar": "كان العرب يراقبون النجوم ويستدلون بها في رحلاتهم. وتناقلوا خبراتهم عبر الأجيال.",
      "en": "Arabs observed the stars and used them to navigate during their journeys. They passed their experience down through generations."
    },
    [
      {
        "ar": "بماذا استدلوا؟",
        "en": "What did they use to navigate?"
      },
      {
        "ar": "بالنجوم",
        "en": "Stars"
      },
      {
        "ar": "بالهواتف",
        "en": "Phones"
      },
      {
        "ar": "بالقطارات",
        "en": "Trains"
      },
      {
        "ar": "النجوم دليل في السفر.",
        "en": "Stars guide travellers."
      }
    ]
  ],
  [
    {
      "ar": "الرحمة بالرعية",
      "en": "Compassion for the people"
    },
    {
      "ar": "يحرص المسؤول العادل على سماع حاجات الناس، ويعاملهم بالرحمة ويحفظ حقوقهم دون تمييز.",
      "en": "A just official listens to people’s needs, treats them compassionately and protects their rights without discrimination."
    },
    [
      {
        "ar": "ما صفة المسؤول؟",
        "en": "What quality does the official have?"
      },
      {
        "ar": "العدل",
        "en": "Justice"
      },
      {
        "ar": "القسوة",
        "en": "Cruelty"
      },
      {
        "ar": "الإهمال",
        "en": "Neglect"
      },
      {
        "ar": "العدل يحفظ الحقوق.",
        "en": "Justice protects rights."
      }
    ]
  ],
  [
    {
      "ar": "الأم",
      "en": "Mother"
    },
    {
      "ar": "تسهر الأم على راحة أبنائها وتشجعهم على النجاح. ومن واجب الأبناء احترامها ومساعدتها.",
      "en": "A mother stays awake to ensure her children’s comfort and encourages them to succeed. Children should respect and help her."
    },
    [
      {
        "ar": "ما واجب الأبناء؟",
        "en": "What is the children’s duty?"
      },
      {
        "ar": "احترام الأم ومساعدتها",
        "en": "Respect and help their mother"
      },
      {
        "ar": "إهمالها",
        "en": "Neglect her"
      },
      {
        "ar": "إزعاجها",
        "en": "Disturb her"
      },
      {
        "ar": "البر يكون بالقول والعمل.",
        "en": "Kindness is shown through words and actions."
      }
    ]
  ],
  [
    {
      "ar": "وقتك حياتك",
      "en": "Your time is your life"
    },
    {
      "ar": "خصصت نور وقتا للدراسة وآخر للراحة. عندما نظمت يومها أنجزت واجباتها دون استعجال.",
      "en": "Noor set aside time for study and time for rest. When she organised her day, she completed her homework without rushing."
    },
    [
      {
        "ar": "لماذا أنجزت واجباتها؟",
        "en": "Why did she complete her homework?"
      },
      {
        "ar": "لأنها نظمت وقتها",
        "en": "Because she organised her time"
      },
      {
        "ar": "لأنها أهملت الدراسة",
        "en": "Because she neglected studying"
      },
      {
        "ar": "لأنها لم تنم",
        "en": "Because she did not sleep"
      },
      {
        "ar": "تنظيم الوقت يساعد على الإنجاز.",
        "en": "Time management helps accomplishment."
      }
    ]
  ],
  [
    {
      "ar": "بغداد",
      "en": "Baghdad"
    },
    {
      "ar": "تقع بغداد على نهر دجلة، وهي مدينة عريقة اشتهرت بالعلم والثقافة. يعتز العراقيون بتاريخ عاصمتهم.",
      "en": "Baghdad lies on the Tigris River. It is an ancient city renowned for knowledge and culture. Iraqis take pride in the history of their capital."
    },
    [
      {
        "ar": "على أي نهر تقع بغداد؟",
        "en": "On which river is Baghdad located?"
      },
      {
        "ar": "دجلة",
        "en": "Tigris"
      },
      {
        "ar": "الفرات",
        "en": "Euphrates"
      },
      {
        "ar": "النيل",
        "en": "Nile"
      },
      {
        "ar": "دجلة يمر ببغداد.",
        "en": "The Tigris runs through Baghdad."
      }
    ]
  ],
  [
    {
      "ar": "العفو عند المقدرة",
      "en": "Forgiveness when able to retaliate"
    },
    {
      "ar": "أخطأ صديق ليلى في حقها، ثم اعتذر بصدق. قبلت اعتذاره رغم قدرتها على الرد بالمثل.",
      "en": "Layla’s friend wronged her and then sincerely apologised. She accepted the apology despite being able to respond in kind."
    },
    [
      {
        "ar": "ما الخلق الذي اتصفت به ليلى؟",
        "en": "What quality did Layla show?"
      },
      {
        "ar": "العفو",
        "en": "Forgiveness"
      },
      {
        "ar": "الحسد",
        "en": "Envy"
      },
      {
        "ar": "الغرور",
        "en": "Arrogance"
      },
      {
        "ar": "العفو ترك الانتقام عند القدرة.",
        "en": "Forgiveness means giving up revenge when able to take it."
      }
    ]
  ],
  [
    {
      "ar": "مبدعونا",
      "en": "Our innovators"
    },
    {
      "ar": "يبدأ الإبداع بفكرة صغيرة، ثم يكبر بالمحاولة والعمل. صنع طالب نموذجا بسيطا لري النباتات فاستفاد منه زملاؤه.",
      "en": "Creativity starts with a small idea and grows through effort and work. A student made a simple model for watering plants, which benefited his classmates."
    },
    [
      {
        "ar": "كيف ينمو الإبداع؟",
        "en": "How does creativity grow?"
      },
      {
        "ar": "بالمحاولة والعمل",
        "en": "Through effort and work"
      },
      {
        "ar": "بترك الأفكار",
        "en": "By abandoning ideas"
      },
      {
        "ar": "بالخوف من التجربة",
        "en": "By fearing experimentation"
      },
      {
        "ar": "التجربة والعمل ينميان الإبداع.",
        "en": "Experimentation and work develop creativity."
      }
    ]
  ]
];
