package iq.lughati;
import android.app.*;import android.os.*;import android.webkit.*;import android.speech.tts.TextToSpeech;import android.speech.RecognizerIntent;import android.content.*;import java.util.*;
public class MainActivity extends Activity {
 WebView web; TextToSpeech tts; boolean ready=false;
 public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,String url){return !url.startsWith("file:///android_asset/");}});web.addJavascriptInterface(new Bridge(),"Native");web.loadUrl("file:///android_asset/index.html");tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS){ready=tts.setLanguage(new Locale("ar"))>=0;}});}
 public class Bridge {
 @JavascriptInterface public boolean configureTutor(String url,String token){try{java.net.URI u=new java.net.URI(url.trim());if(!"https".equals(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||u.getQuery()!=null||u.getFragment()!=null||token.length()<16||token.length()>512)return false;getSharedPreferences("tutor",0).edit().putString("url",url.trim().replaceAll("/+$","")).putString("token",token).apply();return true;}catch(Exception e){return false;}}
 @JavascriptInterface public boolean hasTutorConfiguration(){android.content.SharedPreferences p=getSharedPreferences("tutor",0);return p.getString("url", "").startsWith("https://") && !p.getString("token", "").isEmpty();}
 @JavascriptInterface public void testTutorNative(){
 runOnUiThread(()->{
  android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(MainActivity.this).setTitle("اختبار الاتصال / Connection test").setMessage("Starting HTTPS health check…").setPositiveButton("Close",null).create();
  dialog.show();
  android.os.Handler handler=new android.os.Handler(android.os.Looper.getMainLooper());
  java.util.concurrent.atomic.AtomicBoolean done=new java.util.concurrent.atomic.AtomicBoolean(false);
  handler.postDelayed(()->{if(done.compareAndSet(false,true)){dialog.setMessage("انتهت المهلة / Diagnostic timed out");web.evaluateJavascript("tutorDiagnosticResult(\"Diagnostic timed out / انتهت المهلة\")",null);}},160000);
  new Thread(()->{
   String msg;
   javax.net.ssl.HttpsURLConnection conn=null;
   try{
    android.content.SharedPreferences pref=getSharedPreferences("tutor",0);
    String base=pref.getString("url","");
    if(!base.startsWith("https://"))throw new IllegalArgumentException("HTTPS configuration missing");
    handler.post(()->dialog.setMessage("1/2: Checking HTTPS server…"));
    conn=(javax.net.ssl.HttpsURLConnection)new java.net.URL(base+"/health").openConnection();
    conn.setConnectTimeout(25000);conn.setReadTimeout(75000);conn.setInstanceFollowRedirects(false);
    int health=conn.getResponseCode();conn.disconnect();conn=null;
    if(health!=200)throw new java.io.IOException("Health HTTP "+health);
    handler.post(()->dialog.setMessage("2/2: HTTPS OK. Testing OpenAI with synthetic text…"));
    conn=(javax.net.ssl.HttpsURLConnection)new java.net.URL(base+"/tutor").openConnection();
    conn.setConnectTimeout(25000);conn.setReadTimeout(75000);conn.setInstanceFollowRedirects(false);
    conn.setRequestMethod("POST");conn.setDoOutput(true);
    conn.setRequestProperty("Content-Type","application/json");
    conn.setRequestProperty("Authorization","Bearer "+pref.getString("token",""));
    byte[] payload=new org.json.JSONObject().put("mode","diagnostic").put("consent",true).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
    conn.setFixedLengthStreamingMode(payload.length);
    try(java.io.OutputStream output=conn.getOutputStream()){output.write(payload);}
    int status=conn.getResponseCode();
    java.io.InputStream stream=status==200?conn.getInputStream():conn.getErrorStream();
    String raw="";
    if(stream!=null){try(java.io.InputStream in=stream;java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] buf=new byte[2048];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>100000)throw new java.io.IOException("Response too large");}raw=out.toString("UTF-8");}}
    if(status==200){org.json.JSONObject data=new org.json.JSONObject(raw);msg=data.optString("ar")+" / "+data.optString("en");}
    else{String code="";try{code=new org.json.JSONObject(raw).optString("error","");}catch(Exception ignored){}if(!code.matches("[a-zA-Z0-9_ ]{0,80}"))code="";msg="HTTPS OK; Tutor HTTP "+status+" "+code;}
   }catch(Exception ex){msg="Connection failed / فشل الاتصال: "+ex.getClass().getSimpleName();if(ex instanceof java.io.IOException && ex.getMessage()!=null && ex.getMessage().matches("Health HTTP [0-9]+"))msg+=" "+ex.getMessage();}
   finally{if(conn!=null)conn.disconnect();}
   final String result=msg;handler.post(()->{if(done.compareAndSet(false,true)){dialog.setMessage(result);web.evaluateJavascript("tutorDiagnosticResult("+org.json.JSONObject.quote(result)+")",null);}});
  }).start();
 });
 }
 @JavascriptInterface public void clearTutor(){getSharedPreferences("tutor",0).edit().clear().apply();}
 @JavascriptInterface public void askTutor(int id,String body){new Thread(()->{String result=feedback("تعذر الاتصال بالخادم. تحققي من الإنترنت وعنوان HTTPS.","Unable to connect. Check internet and HTTPS server address.");try{android.content.SharedPreferences p=getSharedPreferences("tutor",0);String url=p.getString("url","");if(!url.startsWith("https://")){final String missing=feedback("المعلم غير مُعدّ. افتحي إعدادات ولي الأمر وأضيفي عنوان الخادم ورمز الوصول.","Tutor not configured. Open parent settings and enter the server URL and access token.");runOnUiThread(()->web.evaluateJavascript("aiReply("+id+","+org.json.JSONObject.quote(missing)+")",null));return;}if(body.length()>1600000)throw new Exception();javax.net.ssl.HttpsURLConnection c=(javax.net.ssl.HttpsURLConnection)new java.net.URL(url+"/tutor").openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(25000);c.setReadTimeout(130000);c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Authorization","Bearer "+p.getString("token",""));c.setDoOutput(true);try(java.io.OutputStream o=c.getOutputStream()){o.write(body.getBytes(java.nio.charset.StandardCharsets.UTF_8));}int status=c.getResponseCode();if(status==200){try(java.io.InputStream in=c.getInputStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>100000)throw new Exception();}result=out.toString("UTF-8");}}else{String code="";try(java.io.InputStream err=c.getErrorStream()){if(err!=null){byte[] buf=new byte[4096];int n=err.read(buf);if(n>0)code=new org.json.JSONObject(new String(buf,0,n,java.nio.charset.StandardCharsets.UTF_8)).optString("error","");}}catch(Exception ignored){}if(!code.matches("[a-zA-Z0-9_ ]{0,80}"))code="";result=feedback("خطأ الخادم: "+status+" "+code,"Server error: "+status+" "+code);}c.disconnect();}catch(java.net.SocketTimeoutException e){result=feedback("انتهت مهلة الاتصال بالخادم.","Server connection timed out.");}catch(Exception e){result=feedback("تعذر الاتصال: "+e.getClass().getSimpleName(),"Connection failed: "+e.getClass().getSimpleName());}final String response=result;runOnUiThread(()->web.evaluateJavascript("aiReply("+id+","+org.json.JSONObject.quote(response)+")",null));}).start();}
@JavascriptInterface public void speak(String s,float rate){runOnUiThread(()->{if(ready){tts.setSpeechRate(rate);tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"reading");}else web.evaluateJavascript("speechError('tts')",null);});} @JavascriptInterface public void listen(){runOnUiThread(()->{try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-IQ");startActivityForResult(i,7);}catch(Exception e){web.evaluateJavascript("speechError('recognition')",null);}});}}
 static String feedback(String ar,String en){try{return new org.json.JSONObject().put("ar",ar).put("en",en).put("error",true).toString();}catch(Exception e){return "{}";}}
 void notifyJs(String s){web.evaluateJavascript("speechResult("+org.json.JSONObject.quote(s)+")",null);}
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==7&&c==RESULT_OK&&d!=null){ArrayList<String> a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(a!=null&&!a.isEmpty())notifyJs(a.get(0));}}
 public void onBackPressed(){web.evaluateJavascript("home()",null);} protected void onDestroy(){if(tts!=null)tts.shutdown();super.onDestroy();}
}
