// Additional original practice questions (v0.5). Merged into the base lessons at load time.
const extraG = [
[
[
{
"ar": "ما نوع كلمة «مدرسة»؟",
"en": "What part of speech is “madrasa” (school)?"
},
{
"ar": "اسم",
"en": "Noun"
},
{
"ar": "فعل",
"en": "Verb"
},
{
"ar": "حرف",
"en": "Particle"
},
{
"ar": "المدرسة اسم مكان ولا ترتبط بزمن.",
"en": "“School” names a place and is not tied to time."
}
],
[
{
"ar": "أيها فعل؟",
"en": "Which is a verb?"
},
{
"ar": "يلعب",
"en": "plays"
},
{
"ar": "ملعب",
"en": "playground"
},
{
"ar": "على",
"en": "on"
},
{
"ar": "يلعب يدل على حدث مرتبط بزمن.",
"en": "“Plays” is an event tied to time."
}
],
[
{
"ar": "أيها حرف؟",
"en": "Which is a particle?"
},
{
"ar": "إلى",
"en": "to"
},
{
"ar": "كتاب",
"en": "book"
},
{
"ar": "نجح",
"en": "succeeded"
},
{
"ar": "إلى حرف جر، ومعناه يظهر مع غيره.",
"en": "“To” is a preposition; its meaning appears with other words."
}
]
],
[
[
{
"ar": "أي الكلمات معربة؟",
"en": "Which word is inflected (changes its ending)?"
},
{
"ar": "معلم",
"en": "teacher"
},
{
"ar": "هذا",
"en": "this"
},
{
"ar": "الذي",
"en": "who/which"
},
{
"ar": "الاسم «معلم» تتغير علامة آخره بتغير موقعه.",
"en": "“Teacher” changes its ending with its position."
}
],
[
{
"ar": "ما حركة «المعلمُ» في: جاء المعلمُ؟",
"en": "What is the vowel of “al-mu‘allimu” in: the teacher came?"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "الكسرة",
"en": "Kasra"
},
{
"ar": "المعلم فاعل مرفوع بالضمة.",
"en": "It is the subject, raised with damma."
}
],
[
{
"ar": "تتغير علامة آخر الاسم المعرب بتغير:",
"en": "The ending of an inflected noun changes with:"
},
{
"ar": "موقعه في الجملة",
"en": "its position in the sentence"
},
{
"ar": "لونه",
"en": "its colour"
},
{
"ar": "عدد حروفه",
"en": "its number of letters"
},
{
"ar": "الإعراب يتبع موقع الكلمة في الجملة.",
"en": "Inflection follows the word’s role in the sentence."
}
]
],
[
[
{
"ar": "أيها علم لمكان؟",
"en": "Which is a proper name of a place?"
},
{
"ar": "بغداد",
"en": "Baghdad"
},
{
"ar": "مدينة",
"en": "city"
},
{
"ar": "نهر",
"en": "river"
},
{
"ar": "بغداد اسم معيّن لمدينة معيّنة.",
"en": "Baghdad names one specific city."
}
],
[
{
"ar": "أيها ليس علماً؟",
"en": "Which is NOT a proper name?"
},
{
"ar": "طالب",
"en": "student"
},
{
"ar": "علي",
"en": "Ali"
},
{
"ar": "دجلة",
"en": "Tigris"
},
{
"ar": "«طالب» اسم عام يصلح لأي طالب.",
"en": "“Student” is a general noun for any student."
}
],
[
{
"ar": "العلم اسم يدل على:",
"en": "A proper name refers to:"
},
{
"ar": "شخص أو مكان معيّن",
"en": "a specific person or place"
},
{
"ar": "أي شخص من الناس",
"en": "any person at all"
},
{
"ar": "حدث في زمن",
"en": "an event in time"
},
{
"ar": "العلم يسمّي شيئاً معيّناً بعينه.",
"en": "A proper name names one particular thing."
}
]
],
[
[
{
"ar": "أيها نكرة؟",
"en": "Which is indefinite?"
},
{
"ar": "كتاب",
"en": "a book"
},
{
"ar": "الكتاب",
"en": "the book"
},
{
"ar": "الطالبات",
"en": "the students"
},
{
"ar": "الكلمة بلا أل ولا إضافة نكرة.",
"en": "A word without al- or possession is indefinite."
}
],
[
{
"ar": "أضف أل التعريف إلى «سماء».",
"en": "Add the definite article to “sama’”."
},
{
"ar": "السماء",
"en": "the sky"
},
{
"ar": "سماءً",
"en": "a sky"
},
{
"ar": "سماوات",
"en": "skies"
},
{
"ar": "نكتب أل في أول الاسم لنعرّفه.",
"en": "We put al- at the start to make it definite."
}
],
[
{
"ar": "أي الكلمات تقبل دخول أل عليها؟",
"en": "Which word can take al-?"
},
{
"ar": "قلم",
"en": "pen"
},
{
"ar": "في",
"en": "in"
},
{
"ar": "هو",
"en": "he"
},
{
"ar": "أل تدخل على الأسماء لا الحروف ولا الضمائر.",
"en": "Al- attaches to nouns, not particles or pronouns."
}
]
],
[
[
{
"ar": "ما الضمير المنفصل للمتكلم؟",
"en": "Which is the separate pronoun for “I”?"
},
{
"ar": "أنا",
"en": "I"
},
{
"ar": "أنتَ",
"en": "you (m.)"
},
{
"ar": "هو",
"en": "he"
},
{
"ar": "أنا ضمير المتكلم.",
"en": "“Ana” is the first-person pronoun."
}
],
[
{
"ar": "أيها ضمير للغائبة؟",
"en": "Which pronoun means “she”?"
},
{
"ar": "هي",
"en": "she"
},
{
"ar": "هو",
"en": "he"
},
{
"ar": "أنتِ",
"en": "you (f.)"
},
{
"ar": "هي ضمير للغائبة المفردة.",
"en": "“Hiya” is third-person feminine."
}
],
[
{
"ar": "ما الضمير المتصل في «كتابُهُ»؟",
"en": "What is the attached pronoun in “kitabuhu”?"
},
{
"ar": "الهاء",
"en": "the letter Ha’"
},
{
"ar": "التاء",
"en": "the letter Ta’"
},
{
"ar": "الواو",
"en": "the letter Waw"
},
{
"ar": "الهاء ضمير متصل للغائب.",
"en": "The Ha’ is an attached pronoun meaning “his”."
}
]
],
[
[
{
"ar": "أشر إلى مفرد مذكر قريب.",
"en": "Point to a near masculine singular."
},
{
"ar": "هذا",
"en": "this (m.)"
},
{
"ar": "هذه",
"en": "this (f.)"
},
{
"ar": "ذلك",
"en": "that (m.)"
},
{
"ar": "هذا للمفرد المذكر القريب.",
"en": "“Hatha” is near masculine singular."
}
],
[
{
"ar": "ما اسم الإشارة في: هذه حديقةٌ جميلةٌ؟",
"en": "What is the demonstrative in: this is a beautiful garden?"
},
{
"ar": "هذه",
"en": "this"
},
{
"ar": "حديقة",
"en": "garden"
},
{
"ar": "جميلة",
"en": "beautiful"
},
{
"ar": "هذه تشير إلى الحديقة.",
"en": "“Hathihi” points to the garden."
}
],
[
{
"ar": "أيها اسم إشارة للبعيد؟",
"en": "Which demonstrative is for something far?"
},
{
"ar": "ذلك",
"en": "that"
},
{
"ar": "هذا",
"en": "this"
},
{
"ar": "هؤلاء",
"en": "these"
},
{
"ar": "ذلك للإشارة إلى البعيد.",
"en": "“Thalika” points to something far."
}
]
],
[
[
{
"ar": "أكمل: جاءت الطالبة ... نجحت.",
"en": "Complete: The student ... passed came."
},
{
"ar": "التي",
"en": "who (f.)"
},
{
"ar": "الذي",
"en": "who (m.)"
},
{
"ar": "الذين",
"en": "who (pl.)"
},
{
"ar": "الطالبة مؤنثة فنستعمل «التي».",
"en": "“Student” is feminine, so we use “allati”."
}
],
[
{
"ar": "أكمل: رأيت الطلاب ... تفوقوا.",
"en": "Complete: I saw the students ... excelled."
},
{
"ar": "الذين",
"en": "who (pl.)"
},
{
"ar": "التي",
"en": "who (f.)"
},
{
"ar": "الذي",
"en": "who (m.)"
},
{
"ar": "الطلاب جمع مذكر فنستعمل «الذين».",
"en": "“Students” is masculine plural, so “alladhina”."
}
],
[
{
"ar": "الاسم الموصول لا يتم معناه إلا بـ:",
"en": "A relative pronoun is not complete without:"
},
{
"ar": "جملة الصلة",
"en": "a relative clause"
},
{
"ar": "فعل أمر",
"en": "an imperative verb"
},
{
"ar": "حرف جر",
"en": "a preposition"
},
{
"ar": "الصلة تكمل معنى الموصول.",
"en": "The clause completes the relative pronoun."
}
]
],
[
[
{
"ar": "ما المضاف في: حديقةُ المدرسةِ واسعةٌ؟",
"en": "What is the first term (mudaf) in: the school’s garden is wide?"
},
{
"ar": "حديقة",
"en": "garden"
},
{
"ar": "المدرسة",
"en": "school"
},
{
"ar": "واسعة",
"en": "wide"
},
{
"ar": "حديقة هي المضاف والمدرسة مضاف إليه.",
"en": "“Garden” is the possessed; “school” is the possessor."
}
],
[
{
"ar": "أي التعبيرات صحيح؟",
"en": "Which phrase is correct?"
},
{
"ar": "كتابُ الطالبِ",
"en": "the student’s book"
},
{
"ar": "الكتابُ الطالبِ",
"en": "the-book the-student"
},
{
"ar": "كتابٌ الطالبِ",
"en": "a-book the-student"
},
{
"ar": "المضاف لا تدخل عليه أل ولا ينوَّن.",
"en": "The first term takes no al- and no tanwin."
}
],
[
{
"ar": "حركة المضاف إليه غالباً:",
"en": "The usual vowel of the second term is:"
},
{
"ar": "الكسرة",
"en": "Kasra"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "المضاف إليه مجرور.",
"en": "The second term is in the genitive."
}
]
],
[
[
{
"ar": "حوّل «يلعب» إلى الماضي.",
"en": "Turn “yal‘abu” into the past."
},
{
"ar": "لعبَ",
"en": "played"
},
{
"ar": "يلعبُ",
"en": "plays"
},
{
"ar": "العبْ",
"en": "play!"
},
{
"ar": "الماضي يدل على حدث انتهى.",
"en": "The past tense shows a finished event."
}
],
[
{
"ar": "ما علامة بناء «كتبتُ»؟",
"en": "What marks the ending of “katabtu”?"
},
{
"ar": "السكون",
"en": "Sukun"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "مبني على السكون لاتصاله بتاء الفاعل.",
"en": "Fixed on sukun because it is joined to the subject Ta’."
}
],
[
{
"ar": "ما علامة بناء «ذهبَ»؟",
"en": "What marks the ending of “dhahaba”?"
},
{
"ar": "الفتح",
"en": "Fatha"
},
{
"ar": "الضم",
"en": "Damma"
},
{
"ar": "السكون",
"en": "Sukun"
},
{
"ar": "الفعل الماضي المجرد يُبنى على الفتح.",
"en": "A plain past verb is fixed on fatha."
}
]
],
[
[
{
"ar": "أيها فعل مضارع؟",
"en": "Which is a present-tense verb?"
},
{
"ar": "يكتبُ",
"en": "writes"
},
{
"ar": "كتبَ",
"en": "wrote"
},
{
"ar": "اكتبْ",
"en": "write!"
},
{
"ar": "المضارع يبدأ بحرف مضارعة.",
"en": "The present starts with a present-tense letter."
}
],
[
{
"ar": "ما علامة رفع «تلعبُ» في: تلعبُ الطفلةُ؟",
"en": "What raises “tal‘abu” in: the girl plays?"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "السكون",
"en": "Sukun"
},
{
"ar": "المضارع المجرد يرفع بالضمة.",
"en": "A plain present verb is raised with damma."
}
],
[
{
"ar": "حروف المضارعة هي:",
"en": "The present-tense letters are:"
},
{
"ar": "أ ن ي ت",
"en": "A, N, Y, T"
},
{
"ar": "ب ت ث",
"en": "B, T, Th"
},
{
"ar": "ق ل م",
"en": "Q, L, M"
},
{
"ar": "نجمعها في كلمة «أنيت».",
"en": "We gather them in the word “anaytu”."
}
]
],
[
[
{
"ar": "ما علامة نصب «يكتبَ» في: لن يكتبَ؟",
"en": "What marks “yaktuba” after “lan”?"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "السكون",
"en": "Sukun"
},
{
"ar": "لن تنصب المضارع بالفتحة.",
"en": "“Lan” puts the present verb in fatha."
}
],
[
{
"ar": "أيها أداة نصب؟",
"en": "Which particle puts a verb in the subjunctive?"
},
{
"ar": "أن",
"en": "that"
},
{
"ar": "لم",
"en": "did not"
},
{
"ar": "هل",
"en": "do/does"
},
{
"ar": "أن تنصب المضارع.",
"en": "“An” makes the verb subjunctive."
}
],
[
{
"ar": "أكمل: أريد أن ... الدرس.",
"en": "Complete: I want to ... the lesson."
},
{
"ar": "أكتبَ",
"en": "write"
},
{
"ar": "أكتبُ",
"en": "write (raised)"
},
{
"ar": "أكتبْ",
"en": "write (jussive)"
},
{
"ar": "بعد أن ننصب المضارع بالفتحة.",
"en": "After “an” the verb takes fatha."
}
]
],
[
[
{
"ar": "أيها أداة جزم؟",
"en": "Which particle makes a verb jussive?"
},
{
"ar": "لم",
"en": "did not"
},
{
"ar": "لن",
"en": "will never"
},
{
"ar": "أن",
"en": "that"
},
{
"ar": "لم تجزم المضارع.",
"en": "“Lam” makes the present verb jussive."
}
],
[
{
"ar": "أكمل: لم ... الطالبُ.",
"en": "Complete: The student did not ... ."
},
{
"ar": "يحضرْ",
"en": "attend"
},
{
"ar": "يحضرَ",
"en": "attend (fatha)"
},
{
"ar": "يحضرُ",
"en": "attend (damma)"
},
{
"ar": "بعد لم يُجزم المضارع بالسكون.",
"en": "After “lam” the verb takes sukun."
}
],
[
{
"ar": "ما علامة جزم «لا تهملْ»؟",
"en": "What marks “la tuhmil”?"
},
{
"ar": "السكون",
"en": "Sukun"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "لا الناهية تجزم المضارع.",
"en": "The prohibitive “la” makes it jussive."
}
]
],
[
[
{
"ar": "أيها من الأفعال الخمسة؟",
"en": "Which is one of the five verbs?"
},
{
"ar": "يكتبون",
"en": "they write"
},
{
"ar": "يكتبُ",
"en": "he writes"
},
{
"ar": "يكتبْ",
"en": "let him write"
},
{
"ar": "فيه واو الجماعة.",
"en": "It has the plural Waw."
}
],
[
{
"ar": "ما علامة نصب «لن يكتبوا»؟",
"en": "What marks the subjunctive of “lan yaktubu”?"
},
{
"ar": "حذف النون",
"en": "dropping the Nun"
},
{
"ar": "ثبوت النون",
"en": "keeping the Nun"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "الأفعال الخمسة تنصب بحذف النون.",
"en": "The five verbs drop the Nun in the subjunctive."
}
],
[
{
"ar": "ما علامة جزم «لم يكتبا»؟",
"en": "What marks the jussive of “lam yaktuba”?"
},
{
"ar": "حذف النون",
"en": "dropping the Nun"
},
{
"ar": "السكون",
"en": "Sukun"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "وتجزم أيضاً بحذف النون.",
"en": "They are jussive by dropping the Nun too."
}
]
],
[
[
{
"ar": "ما الأمر من «يدرس»؟",
"en": "What is the command from “yadrusu”?"
},
{
"ar": "ادرسْ",
"en": "study!"
},
{
"ar": "درس",
"en": "studied"
},
{
"ar": "يدرسُ",
"en": "studies"
},
{
"ar": "نحذف حرف المضارعة ونأتي بهمزة وصل.",
"en": "Drop the present letter and add a connecting hamza."
}
],
[
{
"ar": "ما علامة بناء «اكتبْ»؟",
"en": "What marks the ending of “uktub”?"
},
{
"ar": "السكون",
"en": "Sukun"
},
{
"ar": "الضم",
"en": "Damma"
},
{
"ar": "الفتح",
"en": "Fatha"
},
{
"ar": "فعل الأمر يُبنى على السكون.",
"en": "The command is fixed on sukun."
}
],
[
{
"ar": "أي الجمل فيها فعل أمر؟",
"en": "Which sentence contains a command?"
},
{
"ar": "ذاكرْ دروسك",
"en": "Study your lessons"
},
{
"ar": "ذاكر الطالب دروسه",
"en": "The student studied his lessons"
},
{
"ar": "يذاكر الطالب دروسه",
"en": "The student studies his lessons"
},
{
"ar": "ذاكرْ يطلب القيام بعمل.",
"en": "“Dhakir” asks for an action."
}
]
],
[
[
{
"ar": "من الفاعل في: جاء المعلمُ مبكراً؟",
"en": "Who is the doer in: the teacher came early?"
},
{
"ar": "المعلم",
"en": "the teacher"
},
{
"ar": "جاء",
"en": "came"
},
{
"ar": "مبكراً",
"en": "early"
},
{
"ar": "المعلم هو من قام بالمجيء.",
"en": "The teacher did the coming."
}
],
[
{
"ar": "ما حركة الفاعل؟",
"en": "What vowel does the subject take?"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "الكسرة",
"en": "Kasra"
},
{
"ar": "الفاعل مرفوع.",
"en": "The subject is in the nominative."
}
],
[
{
"ar": "الفاعل يأتي بعد:",
"en": "The subject comes after:"
},
{
"ar": "الفعل",
"en": "the verb"
},
{
"ar": "الحرف",
"en": "the particle"
},
{
"ar": "الاسم الموصول",
"en": "the relative pronoun"
},
{
"ar": "لا فاعل بلا فعل.",
"en": "No subject without a verb."
}
]
],
[
[
{
"ar": "ما الفاعل في «نجحوا»؟",
"en": "What is the doer in “najahu”?"
},
{
"ar": "واو الجماعة",
"en": "plural Waw"
},
{
"ar": "نون",
"en": "Nun"
},
{
"ar": "ألف الاثنين",
"en": "dual Alif"
},
{
"ar": "الواو تدل على جماعة الذكور.",
"en": "The Waw means a group of males."
}
],
[
{
"ar": "ما الفاعل في «كتبنا»؟",
"en": "What is the doer in “katabna”?"
},
{
"ar": "نا",
"en": "“na” (we)"
},
{
"ar": "تاء",
"en": "Ta’"
},
{
"ar": "ياء",
"en": "Ya’"
},
{
"ar": "نا ضمير المتكلمين.",
"en": "“Na” means we."
}
],
[
{
"ar": "ما الفاعل في «يقرآنِ»؟",
"en": "What is the doer in “yaqra’ani”?"
},
{
"ar": "ألف الاثنين",
"en": "dual Alif"
},
{
"ar": "واو",
"en": "Waw"
},
{
"ar": "ياء",
"en": "Ya’"
},
{
"ar": "الألف تدل على اثنين.",
"en": "The Alif means two."
}
]
],
[
[
{
"ar": "ما المفعول به في: أكلَ الولدُ التفاحةَ؟",
"en": "What is the object in: the boy ate the apple?"
},
{
"ar": "التفاحة",
"en": "the apple"
},
{
"ar": "الولد",
"en": "the boy"
},
{
"ar": "أكل",
"en": "ate"
},
{
"ar": "التفاحة وقع عليها الأكل.",
"en": "The eating fell on the apple."
}
],
[
{
"ar": "حركة المفعول به المفرد:",
"en": "The vowel of a singular object:"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "الكسرة",
"en": "Kasra"
},
{
"ar": "المفعول به منصوب.",
"en": "The object is in the accusative."
}
],
[
{
"ar": "المفعول به هو ما وقع عليه:",
"en": "The object is what receives:"
},
{
"ar": "فعل الفاعل",
"en": "the doer’s action"
},
{
"ar": "الزمان",
"en": "the time"
},
{
"ar": "الحرف",
"en": "the particle"
},
{
"ar": "الفاعل يفعل والمفعول يقع عليه الفعل.",
"en": "The subject acts; the object receives."
}
]
],
[
[
{
"ar": "ما المبتدأ في: العلمُ نورٌ؟",
"en": "What is the topic (mubtada’) in: knowledge is light?"
},
{
"ar": "العلم",
"en": "knowledge"
},
{
"ar": "نور",
"en": "light"
},
{
"ar": "في",
"en": "in"
},
{
"ar": "المبتدأ ما نبدأ به الجملة الاسمية.",
"en": "It is what the noun sentence starts with."
}
],
[
{
"ar": "حركة المبتدأ والخبر المفردين:",
"en": "Vowel of a singular topic and predicate:"
},
{
"ar": "الضمة",
"en": "Damma"
},
{
"ar": "الفتحة",
"en": "Fatha"
},
{
"ar": "الكسرة",
"en": "Kasra"
},
{
"ar": "كلاهما مرفوع.",
"en": "Both are nominative."
}
],
[
{
"ar": "أكمل: الطالبةُ ...",
"en": "Complete: The student is ..."
},
{
"ar": "مجتهدةٌ",
"en": "hard-working"
},
{
"ar": "مجتهدةً",
"en": "hard-working (acc.)"
},
{
"ar": "مجتهدةِ",
"en": "hard-working (gen.)"
},
{
"ar": "الخبر المفرد مرفوع.",
"en": "The singular predicate is raised."
}
]
],
[
[
{
"ar": "ما اسم كان في: كان الجوُّ جميلاً؟",
"en": "What is the subject of “kana” in: the weather was beautiful?"
},
{
"ar": "الجو",
"en": "the weather"
},
{
"ar": "جميلاً",
"en": "beautiful"
},
{
"ar": "كان",
"en": "was"
},
{
"ar": "اسم كان مرفوع.",
"en": "The subject of “kana” is raised."
}
],
[
{
"ar": "خبر كان يكون:",
"en": "The predicate of “kana” is:"
},
{
"ar": "منصوباً",
"en": "accusative"
},
{
"ar": "مرفوعاً",
"en": "nominative"
},
{
"ar": "مجروراً",
"en": "genitive"
},
{
"ar": "كان ترفع الاسم وتنصب الخبر.",
"en": "“Kana” raises the subject and puts the predicate in accusative."
}
],
[
{
"ar": "أيها من أخوات كان؟",
"en": "Which is a sister of “kana”?"
},
{
"ar": "أصبح",
"en": "became"
},
{
"ar": "ذهب",
"en": "went"
},
{
"ar": "قرأ",
"en": "read"
},
{
"ar": "أصبح من النواسخ.",
"en": "“Asbaha” is one of the abrogators."
}
]
],
[
[
{
"ar": "ما خبر إنّ في: إنّ الصدقَ منجاةٌ؟",
"en": "What is the predicate of “inna” in: truthfulness is a rescue?"
},
{
"ar": "منجاة",
"en": "a rescue"
},
{
"ar": "الصدق",
"en": "truthfulness"
},
{
"ar": "إن",
"en": "indeed"
},
{
"ar": "الخبر مرفوع بعد إن.",
"en": "The predicate stays raised after “inna”."
}
],
[
{
"ar": "اسم إنّ يكون:",
"en": "The subject of “inna” is:"
},
{
"ar": "منصوباً",
"en": "accusative"
},
{
"ar": "مرفوعاً",
"en": "nominative"
},
{
"ar": "مجروراً",
"en": "genitive"
},
{
"ar": "إن تنصب الاسم وترفع الخبر.",
"en": "“Inna” puts the subject in accusative and raises the predicate."
}
],
[
{
"ar": "أيها من أخوات إنّ؟",
"en": "Which is a sister of “inna”?"
},
{
"ar": "لكنّ",
"en": "but"
},
{
"ar": "كان",
"en": "was"
},
{
"ar": "لم",
"en": "did not"
},
{
"ar": "لكنّ من أخوات إن.",
"en": "“Lakinna” is a sister of “inna”."
}
]
],
[
[
{
"ar": "أكمل: كان الطالبُ ...",
"en": "Complete: The student was ..."
},
{
"ar": "مجتهداً",
"en": "hard-working (acc.)"
},
{
"ar": "مجتهدٌ",
"en": "hard-working (nom.)"
},
{
"ar": "مجتهدِ",
"en": "hard-working (gen.)"
},
{
"ar": "بعد كان ننصب الخبر.",
"en": "After “kana” the predicate is accusative."
}
],
[
{
"ar": "أكمل: إنّ الطالبَ ...",
"en": "Complete: Indeed the student is ..."
},
{
"ar": "مجتهدٌ",
"en": "hard-working (nom.)"
},
{
"ar": "مجتهداً",
"en": "hard-working (acc.)"
},
{
"ar": "مجتهدِ",
"en": "hard-working (gen.)"
},
{
"ar": "بعد إن يرفع الخبر.",
"en": "After “inna” the predicate is raised."
}
],
[
{
"ar": "أي الجمل صحيحة؟",
"en": "Which sentence is correct?"
},
{
"ar": "لم يكتبْ الولدُ",
"en": "The boy did not write"
},
{
"ar": "لم يكتبُ الولدُ",
"en": "(wrong vowel)"
},
{
"ar": "لم يكتبَ الولدُ",
"en": "(wrong vowel)"
},
{
"ar": "لم تجزم المضارع بالسكون.",
"en": "“Lam” gives the verb sukun."
}
]
]
];
const extraR = [
[
[
{
"ar": "ماذا تفعل الأمطار حسب النص؟",
"en": "What do the rains do, according to the text?"
},
{
"ar": "تسقي الأرض",
"en": "They water the earth"
},
{
"ar": "تلوّث الماء",
"en": "They pollute the water"
},
{
"ar": "تجفف الأنهار",
"en": "They dry the rivers"
},
{
"ar": "ذكر النص أن الأمطار تسقي الأرض.",
"en": "The text says the rains water the earth."
}
],
[
{
"ar": "من يشرب الماء في النص؟",
"en": "Who drinks water in the text?"
},
{
"ar": "الإنسان والحيوان",
"en": "People and animals"
},
{
"ar": "الإنسان فقط",
"en": "People only"
},
{
"ar": "النبات فقط",
"en": "Plants only"
},
{
"ar": "ذكر النص الإنسان والحيوان.",
"en": "The text names people and animals."
}
]
],
[
[
{
"ar": "كم مرة تذهب زهراء إلى المكتبة؟",
"en": "How often does Zahra go to the library?"
},
{
"ar": "كل أسبوع",
"en": "Every week"
},
{
"ar": "كل يوم",
"en": "Every day"
},
{
"ar": "كل شهر",
"en": "Every month"
},
{
"ar": "ورد: كل أسبوع.",
"en": "The text says: every week."
}
],
[
{
"ar": "أين تسجل زهراء ما تعلمته؟",
"en": "Where does Zahra note what she learned?"
},
{
"ar": "في دفتر صغير",
"en": "In a small notebook"
},
{
"ar": "على السبورة",
"en": "On the board"
},
{
"ar": "في الحاسوب",
"en": "On a computer"
},
{
"ar": "ورد: دفتر صغير.",
"en": "The text says: a small notebook."
}
]
],
[
[
{
"ar": "ماذا وصف الرحالة العرب؟",
"en": "What did the Arab travellers describe?"
},
{
"ar": "البلدان التي زاروها",
"en": "The countries they visited"
},
{
"ar": "الحروب فقط",
"en": "Only wars"
},
{
"ar": "النجوم",
"en": "The stars"
},
{
"ar": "ورد في أول النص.",
"en": "It is in the first sentence."
}
],
[
{
"ar": "ماذا سجلوا؟",
"en": "What did they record?"
},
{
"ar": "عادات الناس وطرق عيشهم",
"en": "People’s customs and ways of life"
},
{
"ar": "أسعار البضائع",
"en": "Goods’ prices"
},
{
"ar": "أسماء السفن",
"en": "Ships’ names"
},
{
"ar": "ورد في النص.",
"en": "It is stated in the text."
}
]
],
[
[
{
"ar": "ماذا يستطيع القارئ أن يتعرف عليه؟",
"en": "What can the reader get to know?"
},
{
"ar": "أماكن بعيدة",
"en": "Faraway places"
},
{
"ar": "ألعاباً جديدة",
"en": "New games"
},
{
"ar": "أسواقاً قريبة",
"en": "Nearby markets"
},
{
"ar": "دون أن يغادر غرفته.",
"en": "Without leaving the room."
}
],
[
{
"ar": "ماذا يكتسب القارئ كل يوم؟",
"en": "What does the reader gain every day?"
},
{
"ar": "أفكاراً جديدة",
"en": "New ideas"
},
{
"ar": "مالاً",
"en": "Money"
},
{
"ar": "لعبة",
"en": "A toy"
},
{
"ar": "ورد: أفكاراً جديدة.",
"en": "The text says: new ideas."
}
]
],
[
[
{
"ar": "أين وجدت مريم المحفظة؟",
"en": "Where did Maryam find the wallet?"
},
{
"ar": "في ساحة المدرسة",
"en": "In the schoolyard"
},
{
"ar": "في الصف",
"en": "In the classroom"
},
{
"ar": "في البيت",
"en": "At home"
},
{
"ar": "ورد: ساحة المدرسة.",
"en": "The text says: the schoolyard."
}
],
[
{
"ar": "ماذا فعلت مريم بالمحفظة؟",
"en": "What did Maryam do with the wallet?"
},
{
"ar": "أعطتها للمعلمة",
"en": "Gave it to the teacher"
},
{
"ar": "احتفظت بها",
"en": "Kept it"
},
{
"ar": "رمتها",
"en": "Threw it away"
},
{
"ar": "لتعيدها إلى صاحبتها.",
"en": "So it could be returned to its owner."
}
]
],
[
[
{
"ar": "ماذا ظن سامر عن الهدية؟",
"en": "What did Samer think of the gift?"
},
{
"ar": "أنها لا قيمة لها",
"en": "It was worthless"
},
{
"ar": "أنها غالية",
"en": "It was expensive"
},
{
"ar": "أنها قديمة",
"en": "It was old"
},
{
"ar": "ظن أنها بسيطة.",
"en": "He thought it was too simple."
}
],
[
{
"ar": "كيف صُنعت الهدية؟",
"en": "How was the gift made?"
},
{
"ar": "بيدي الصديق خلال أيام",
"en": "By the friend’s hands over days"
},
{
"ar": "اشتُريت من متجر",
"en": "Bought from a shop"
},
{
"ar": "في ساعة واحدة",
"en": "In one hour"
},
{
"ar": "ورد في النص.",
"en": "The text says so."
}
]
],
[
[
{
"ar": "على ماذا اختلف الطالبان؟",
"en": "What did the two students disagree about?"
},
{
"ar": "لعبة",
"en": "A game"
},
{
"ar": "درس",
"en": "A lesson"
},
{
"ar": "كتاب",
"en": "A book"
},
{
"ar": "ورد: في لعبة.",
"en": "The text says: in a game."
}
],
[
{
"ar": "ماذا فعل كل منهما؟",
"en": "What did each of them do?"
},
{
"ar": "اعتذر للآخر",
"en": "Apologised to the other"
},
{
"ar": "غضب",
"en": "Got angry"
},
{
"ar": "ترك المكان",
"en": "Left"
},
{
"ar": "وعادا إلى اللعب.",
"en": "And they went back to playing."
}
]
],
[
[
{
"ar": "ما الذي يحافظ عليه أبناء العراق؟",
"en": "What do Iraq’s people take care of?"
},
{
"ar": "مدنه وأنهاره",
"en": "Its cities and rivers"
},
{
"ar": "الأسواق فقط",
"en": "Only markets"
},
{
"ar": "الصحراء فقط",
"en": "Only the desert"
},
{
"ar": "ورد في النص.",
"en": "It is in the text."
}
],
[
{
"ar": "ماذا يفعلون في الأحياء؟",
"en": "What do they do in the neighbourhoods?"
},
{
"ar": "ينظفونها",
"en": "Clean them"
},
{
"ar": "يهملونها",
"en": "Neglect them"
},
{
"ar": "يغلقونها",
"en": "Close them"
},
{
"ar": "يتعاونون في تنظيفها.",
"en": "They cooperate in cleaning."
}
]
],
[
[
{
"ar": "أي مهنة ذكرها النص للمرأة؟",
"en": "Which job does the text mention for women?"
},
{
"ar": "الطبيبة",
"en": "Doctor"
},
{
"ar": "الطيارة",
"en": "Pilot"
},
{
"ar": "السائقة",
"en": "Driver"
},
{
"ar": "ذكر النص الطبيبة والمعلمة والمهندسة.",
"en": "It lists doctor, teacher and engineer."
}
],
[
{
"ar": "لماذا تعمل هؤلاء النساء؟",
"en": "Why do these women work?"
},
{
"ar": "لخدمة المجتمع",
"en": "To serve society"
},
{
"ar": "للراحة فقط",
"en": "For rest only"
},
{
"ar": "لتجنب الناس",
"en": "To avoid people"
},
{
"ar": "ورد: لخدمة المجتمع.",
"en": "The text says: to serve society."
}
]
],
[
[
{
"ar": "كم تجمع اللغة العربية من الناس؟",
"en": "How many people does Arabic bring together?"
},
{
"ar": "ملايين",
"en": "Millions"
},
{
"ar": "عدداً قليلاً",
"en": "A few"
},
{
"ar": "عشرات",
"en": "Dozens"
},
{
"ar": "ورد: ملايين.",
"en": "The text says: millions."
}
],
[
{
"ar": "ماذا تفتح لنا اللغة؟",
"en": "What does the language open for us?"
},
{
"ar": "أبواب المعرفة والتراث",
"en": "Doors to knowledge and heritage"
},
{
"ar": "أبواب المدرسة",
"en": "School doors"
},
{
"ar": "أبواب السوق",
"en": "Market doors"
},
{
"ar": "ورد في النص.",
"en": "It is in the text."
}
]
],
[
[
{
"ar": "ماذا وضع التلاميذ في المدرسة؟",
"en": "What did the pupils put in the school?"
},
{
"ar": "حاويات للنفايات",
"en": "Waste bins"
},
{
"ar": "ألعاباً",
"en": "Toys"
},
{
"ar": "أجهزة",
"en": "Devices"
},
{
"ar": "ورد في النص.",
"en": "It is in the text."
}
],
[
{
"ar": "ماذا تغيّر بعد زرع الأشجار؟",
"en": "What changed after planting trees?"
},
{
"ar": "أصبحت الساحة أجمل",
"en": "The yard became nicer"
},
{
"ar": "أغلقت المدرسة",
"en": "The school closed"
},
{
"ar": "قلّ الطلاب",
"en": "Fewer pupils"
},
{
"ar": "وصار الهواء ألطف.",
"en": "And the air became milder."
}
]
],
[
[
{
"ar": "كم رغيفاً كان مع حسن؟",
"en": "How many loaves did Hasan have?"
},
{
"ar": "رغيفاً واحداً",
"en": "One loaf"
},
{
"ar": "رغيفين",
"en": "Two loaves"
},
{
"ar": "ثلاثة أرغفة",
"en": "Three loaves"
},
{
"ar": "ورد: رغيف واحد.",
"en": "The text says: one loaf."
}
],
[
{
"ar": "بماذا شعر حسن؟",
"en": "How did Hasan feel?"
},
{
"ar": "بالسعادة",
"en": "Happy"
},
{
"ar": "بالخوف",
"en": "Afraid"
},
{
"ar": "بالغضب",
"en": "Angry"
},
{
"ar": "لأنه ساعد صديقه.",
"en": "Because he helped his friend."
}
]
],
[
[
{
"ar": "ماذا كان العرب يراقبون؟",
"en": "What did the Arabs watch?"
},
{
"ar": "النجوم",
"en": "The stars"
},
{
"ar": "الجبال",
"en": "The mountains"
},
{
"ar": "الأنهار",
"en": "The rivers"
},
{
"ar": "ورد: النجوم.",
"en": "The text says: the stars."
}
],
[
{
"ar": "كيف انتقلت خبراتهم؟",
"en": "How were their experiences passed on?"
},
{
"ar": "عبر الأجيال",
"en": "Across generations"
},
{
"ar": "بالإنترنت",
"en": "By the internet"
},
{
"ar": "بالتلفاز",
"en": "By television"
},
{
"ar": "ورد: عبر الأجيال.",
"en": "The text says: across generations."
}
]
],
[
[
{
"ar": "ماذا يحرص المسؤول العادل عليه؟",
"en": "What does a fair official care about?"
},
{
"ar": "سماع حاجات الناس",
"en": "Hearing people’s needs"
},
{
"ar": "جمع الأموال",
"en": "Collecting money"
},
{
"ar": "السفر",
"en": "Travelling"
},
{
"ar": "ورد في النص.",
"en": "It is in the text."
}
],
[
{
"ar": "كيف يعامل الناس؟",
"en": "How does he treat people?"
},
{
"ar": "بالرحمة",
"en": "With mercy"
},
{
"ar": "بالقسوة",
"en": "With harshness"
},
{
"ar": "بالتمييز",
"en": "With discrimination"
},
{
"ar": "ورد: بالرحمة.",
"en": "The text says: with mercy."
}
]
],
[
[
{
"ar": "ماذا تفعل الأم لراحة أبنائها؟",
"en": "What does a mother do for her children’s comfort?"
},
{
"ar": "تسهر عليها",
"en": "Stays up for it"
},
{
"ar": "تهملها",
"en": "Neglects it"
},
{
"ar": "تتركها",
"en": "Leaves it"
},
{
"ar": "ورد: تسهر.",
"en": "The text says: stays up."
}
],
[
{
"ar": "ماذا تفعل الأم ليكون الأبناء ناجحين؟",
"en": "What does she do so her children succeed?"
},
{
"ar": "تشجعهم على النجاح",
"en": "Encourages them"
},
{
"ar": "تمنعهم من الدراسة",
"en": "Stops them studying"
},
{
"ar": "تتجاهلهم",
"en": "Ignores them"
},
{
"ar": "ورد في النص.",
"en": "It is in the text."
}
]
],
[
[
{
"ar": "ماذا خصصت نور؟",
"en": "What did Nour set aside?"
},
{
"ar": "وقتاً للدراسة وآخر للراحة",
"en": "Time to study and time to rest"
},
{
"ar": "وقتاً للعب فقط",
"en": "Time only to play"
},
{
"ar": "وقتاً للنوم فقط",
"en": "Time only to sleep"
},
{
"ar": "ورد في النص.",
"en": "It is in the text."
}
],
[
{
"ar": "كيف أنجزت نور واجباتها؟",
"en": "How did Nour finish her homework?"
},
{
"ar": "دون استعجال",
"en": "Without rushing"
},
{
"ar": "بسرعة وتعب",
"en": "Fast and tired"
},
{
"ar": "دون تنظيم",
"en": "Without a plan"
},
{
"ar": "لأنها نظمت يومها.",
"en": "Because she organised her day."
}
]
],
[
[
{
"ar": "بماذا اشتهرت بغداد؟",
"en": "What is Baghdad famous for?"
},
{
"ar": "بالعلم والثقافة",
"en": "Knowledge and culture"
},
{
"ar": "بالجبال",
"en": "Mountains"
},
{
"ar": "بالصحراء",
"en": "Desert"
},
{
"ar": "ورد في النص.",
"en": "It is in the text."
}
],
[
{
"ar": "بماذا يعتز العراقيون؟",
"en": "What are Iraqis proud of?"
},
{
"ar": "بتاريخ عاصمتهم",
"en": "Their capital’s history"
},
{
"ar": "بالسفر",
"en": "Travelling"
},
{
"ar": "بالتجارة فقط",
"en": "Trade only"
},
{
"ar": "ورد في النص.",
"en": "It is in the text."
}
]
],
[
[
{
"ar": "ماذا فعل صديق ليلى؟",
"en": "What did Layla’s friend do?"
},
{
"ar": "اعتذر بصدق",
"en": "Apologised sincerely"
},
{
"ar": "ضحك",
"en": "Laughed"
},
{
"ar": "هرب",
"en": "Ran away"
},
{
"ar": "ثم اعتذر.",
"en": "Then he apologised."
}
],
[
{
"ar": "ماذا فعلت ليلى؟",
"en": "What did Layla do?"
},
{
"ar": "قبلت اعتذاره",
"en": "Accepted his apology"
},
{
"ar": "انتقمت",
"en": "Took revenge"
},
{
"ar": "تجاهلته",
"en": "Ignored him"
},
{
"ar": "رغم قدرتها على الرد.",
"en": "Despite being able to retaliate."
}
]
],
[
[
{
"ar": "بماذا يبدأ الإبداع؟",
"en": "What does creativity begin with?"
},
{
"ar": "بفكرة صغيرة",
"en": "A small idea"
},
{
"ar": "بمال كبير",
"en": "A lot of money"
},
{
"ar": "بجائزة",
"en": "A prize"
},
{
"ar": "ورد: فكرة صغيرة.",
"en": "The text says: a small idea."
}
],
[
{
"ar": "ماذا صنع الطالب؟",
"en": "What did the student make?"
},
{
"ar": "نموذجاً لري النباتات",
"en": "A plant-watering model"
},
{
"ar": "لعبة",
"en": "A toy"
},
{
"ar": "كتاباً",
"en": "A book"
},
{
"ar": "فاستفاد منه زملاؤه.",
"en": "His classmates benefited."
}
]
]
];
extraG.forEach((qs,i)=>{if(grammar[i])grammar[i][3].push(...qs)});
const readingQs = reading.map((r,i)=>[r[2],...(extraR[i]||[])]);
